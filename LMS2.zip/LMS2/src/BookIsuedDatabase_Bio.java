
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author docto
 */
public class BookIsuedDatabase_Bio {
    
    File bookfile;
    PrintWriter out;
    BufferedReader in;
    ArrayList<BookIsued_Bio> books;
    
    
    public BookIsuedDatabase_Bio(){
        
        bookfile = new File("booksisued_bio.txt");
        try {
            out = new PrintWriter(new FileWriter(bookfile, true));
            in = new BufferedReader(new FileReader(bookfile));
        } catch (IOException ex) {
            Logger.getLogger(StudentDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        books = new ArrayList<BookIsued_Bio>();
    
    }
    
    public void writeToDatabase(String bookname, int userid){
        
        out.println(String.valueOf(bookname) + "#" + String.valueOf(userid));
        out.close();
    
    }
    
    public ArrayList<BookIsued_Bio> readFromDatabase(){
        String line = null;
        try {
            while((line = in.readLine()) != null){
                String[] list = line.split(Pattern.quote("#"));
                String bookname = list[0];
                int userid = Integer.valueOf(list[1]);
                
               
                
                books.add(new BookIsued_Bio(bookname, userid));
            }
            
            in.close();
            
        } catch (IOException ex) {
            Logger.getLogger(StudentDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    return books;
    }
    
}
