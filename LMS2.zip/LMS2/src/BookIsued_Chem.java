/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author docto
 */
public class BookIsued_Chem {
 String bookname;
    int userid;
    
    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }


    
   
    
    
    public BookIsued_Chem(String bookname, int userid){
        
        this.bookname = bookname;
        this.userid = userid;
      
    
    }
    
    
    
}
