
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author docto
 */
public class StudentDatabase {
    
    File studentfile;
    PrintWriter out;
    BufferedReader in;
    ArrayList<Student> students;
    
    public StudentDatabase(){
    
        studentfile = new File("student.txt");
        try {
            out = new PrintWriter(new FileWriter(studentfile, true));
            in = new BufferedReader(new FileReader(studentfile));
        } catch (IOException ex) {
            Logger.getLogger(StudentDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void writeToDatabase(int userid, String username, int semester,String institute){
        
        out.println(String.valueOf(userid) + "-" + username + "-" + String.valueOf(semester) + "-" + institute);
        out.close();
    
    }
    
    public ArrayList<Student> readFromDatabase(){
        String line = null;
        try {
           while((line = in.readLine()) != null){
                String[] list = line.split(Pattern.quote("-"));
                int userid = Integer.valueOf(list[0]);
                String username = list[1];
                int semester = Integer.valueOf(list[2]);
                String institute = list[3];
                
                students.add(new Student(userid, username, semester, institute));
            }
            
            in.close();
            
        } catch (IOException ex) {
            Logger.getLogger(StudentDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    return students;
    }
    
    
    
}
