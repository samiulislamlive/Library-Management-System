/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author docto
 */
public class EnglishBook {
    
    String bookname;
    int quantity;

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    
    public EnglishBook(String bookname, int quantity){
        
        this.bookname = bookname;
        this.quantity = quantity;
    
    }
    
}
