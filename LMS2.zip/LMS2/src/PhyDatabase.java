
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author docto
 */
public class PhyDatabase {
    
   File bookfile;
    PrintWriter out;
    BufferedReader in;
    ArrayList<PhyBook> books;
    
    
    public PhyDatabase(){
        
        bookfile = new File("phybooks.txt");
        try {
            out = new PrintWriter(new FileWriter(bookfile, true));
            in = new BufferedReader(new FileReader(bookfile));
        } catch (IOException ex) {
            Logger.getLogger(StudentDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        books = new ArrayList<PhyBook>();
    
    }
    
    public void writeToDatabase(String bookname, int userid, int quantity){
        
        out.println(String.valueOf(bookname) + "#" + String.valueOf(quantity));
        out.close();
    
    }
    
    public ArrayList<PhyBook> readFromDatabase(){
        String line = "";
        try {
            while((line = in.readLine()) != null){
                String[] list = line.split(Pattern.quote("#"));
                //System.out.println(list[0]);
                //System.out.println(list[1]);
                String bookname = list[0];
                int quantity = Integer.valueOf(list[1]);
               
                
                books.add(new PhyBook(bookname, quantity));
            }
            
            in.close();
            
        } catch (IOException ex) {
            Logger.getLogger(StudentDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    return books;
    }
    
}
